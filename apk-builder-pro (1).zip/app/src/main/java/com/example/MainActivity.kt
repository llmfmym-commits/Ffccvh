package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.tapsell.TapsellAdManager
import com.example.ui.theme.MyApplicationTheme
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {

    private var activeWebView: WebView? = null
    private var customVideoView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var fullscreenContainer: FrameLayout? = null

    // مدیریت درخواست مجوزهای WebRTC وب‌سایت
    private var pendingWebPermissionRequest: PermissionRequest? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted && pendingWebPermissionRequest != null) {
            pendingWebPermissionRequest?.grant(pendingWebPermissionRequest?.resources)
        } else {
            pendingWebPermissionRequest?.deny()
        }
        pendingWebPermissionRequest = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // راه‌اندازی اختیاری تپسل بر اساس BuildConfig
        if (BuildConfig.TAPSELL_ENABLED && BuildConfig.TAPSELL_APP_KEY.isNotBlank()) {
            TapsellAdManager.initialize(this, BuildConfig.TAPSELL_APP_KEY)
        }

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0A0F1D)
                ) {
                    WebViewApp(
                        activity = this,
                        onAttachWebView = { activeWebView = it },
                        onShowCustomView = { view, callback ->
                            showCustomView(view, callback)
                        },
                        onHideCustomView = {
                            hideCustomView()
                        },
                        onRequestWebPermissions = { request ->
                            handleWebPermissionRequest(request)
                        }
                    )
                }
            }
        }

        // مدیریت دکمه فیزیکی بازگشت
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customVideoView != null) {
                    hideCustomView()
                } else if (activeWebView?.canGoBack() == true) {
                    activeWebView?.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    private fun showCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
        if (customVideoView != null) {
            callback.onCustomViewHidden()
            return
        }
        customVideoView = view
        customViewCallback = callback
        fullscreenContainer?.addView(
            view,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        fullscreenContainer?.visibility = View.VISIBLE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun hideCustomView() {
        if (customVideoView == null) return
        fullscreenContainer?.removeView(customVideoView)
        fullscreenContainer?.visibility = View.GONE
        customViewCallback?.onCustomViewHidden()
        customVideoView = null
        customViewCallback = null
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    private fun handleWebPermissionRequest(request: PermissionRequest) {
        pendingWebPermissionRequest = request
        val needed = mutableListOf<String>()

        if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.CAMERA)
            }
        }
        if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.RECORD_AUDIO)
            }
        }

        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        } else {
            request.grant(request.resources)
            pendingWebPermissionRequest = null
        }
    }

    fun setFullscreenContainer(container: FrameLayout) {
        this.fullscreenContainer = container
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        activeWebView?.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        activeWebView?.restoreState(savedInstanceState)
    }

    override fun onDestroy() {
        activeWebView?.destroy()
        activeWebView = null
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewApp(
    activity: MainActivity,
    onAttachWebView: (WebView) -> Unit,
    onShowCustomView: (View, WebChromeClient.CustomViewCallback) -> Unit,
    onHideCustomView: () -> Unit,
    onRequestWebPermissions: (PermissionRequest) -> Unit
) {
    val context = LocalContext.current

    // حالت منبع وب: بر اساس پیکربندی گرادل یا تغییر دستی
    var currentSourceType by rememberSaveable { mutableStateOf(BuildConfig.SOURCE_TYPE) }
    var currentUrl by rememberSaveable { mutableStateOf(BuildConfig.APP_URL) }
    var currentHtmlFile by rememberSaveable { mutableStateOf(BuildConfig.HTML_FILE) }

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var loadProgress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(true) }
    var pageError by remember { mutableStateOf<String?>(null) }

    // کنترل پنل تنظیمات قالب
    var showInspectorSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // بنر تست تپسل
    var showTapsellBanner by rememberSaveable { mutableStateOf(BuildConfig.TAPSELL_ENABLED) }

    // محاسبه آدرس نهایی جهت بارگذاری
    val targetUrl = remember(currentSourceType, currentUrl, currentHtmlFile) {
        if (currentSourceType.equals("HTML", ignoreCase = true)) {
            "file:///android_asset/$currentHtmlFile"
        } else {
            currentUrl
        }
    }

    LaunchedEffect(targetUrl) {
        pageError = null
        webViewInstance?.loadUrl(targetUrl)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // نوار پیشرفت بارگذاری صفحه
            AnimatedVisibility(visible = isLoading && loadProgress < 1f) {
                LinearProgressIndicator(
                    progress = { loadProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = Color(0xFF0284C7),
                    trackColor = Color.Transparent
                )
            }

            // فضای اصلی وب‌ویو
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )

                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                allowFileAccess = true
                                allowContentAccess = true
                                loadsImagesAutomatically = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                builtInZoomControls = true
                                displayZoomControls = false
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                cacheMode = WebSettings.LOAD_DEFAULT
                                userAgentString = settings.userAgentString + " AirTubeApp/1.0"
                            }

                            // فعال‌سازی رسمی کوکی‌ها
                            val cookieManager = CookieManager.getInstance()
                            cookieManager.setAcceptCookie(true)
                            cookieManager.setAcceptThirdPartyCookies(this, true)

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    loadProgress = newProgress / 100f
                                    isLoading = newProgress < 100
                                }

                                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                                    if (view != null && callback != null) {
                                        onShowCustomView(view, callback)
                                    }
                                }

                                override fun onHideCustomView() {
                                    onHideCustomView()
                                }

                                override fun onPermissionRequest(request: PermissionRequest?) {
                                    if (request != null) {
                                        onRequestWebPermissions(request)
                                    }
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    isLoading = true
                                    pageError = null
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    isLoading = false
                                }

                                override fun onReceivedError(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                    error: WebResourceError?
                                ) {
                                    super.onReceivedError(view, request, error)
                                    if (request?.isForMainFrame == true) {
                                        pageError = error?.description?.toString() ?: "خطا در اتصال به اینترنت"
                                    }
                                }

                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    val uri = request?.url ?: return false
                                    val scheme = uri.scheme ?: ""
                                    if (scheme.equals("http", true) || scheme.equals("https", true) || scheme.equals("file", true)) {
                                        return false
                                    }
                                    return try {
                                        val intent = Intent(Intent.ACTION_VIEW, uri)
                                        ctx.startActivity(intent)
                                        true
                                    } catch (e: Exception) {
                                        false
                                    }
                                }
                            }

                            webViewInstance = this
                            onAttachWebView(this)
                            loadUrl(targetUrl)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // پیام خطای اتصال با دکمه تلاش مجدد
                if (pageError != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF0F172A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Text(
                                text = "⚠️ عدم برقراری ارتباط با سرور",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = pageError ?: "",
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    pageError = null
                                    webViewInstance?.reload()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تلاش مجدد")
                            }
                        }
                    }
                }
            }

            // بنر تپسل (Tapsell Banner) در انتهای صفحه
            AnimatedVisibility(visible = showTapsellBanner) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E293B))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .navigationBarsPadding(),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "📢 بنر تبلیغاتی استاندارد تپسل (Tapsell Plus)",
                                color = Color(0xFF38BDF8),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Zone ID: ${BuildConfig.TAPSELL_BANNER_ZONE_ID.ifBlank { "پیش‌نمایش قالب" }}",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                        }
                        IconButton(
                            onClick = { showTapsellBanner = false },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "بستن بنر",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // فریم اختصاصی جهت پخش تمام‌صفحه ویدیو (Web Fullscreen Video)
        AndroidView(
            factory = { ctx ->
                FrameLayout(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    visibility = View.GONE
                    activity.setFullscreenContainer(this)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // دکمه شناور باز کردن کنترل‌پنل قالب و خروجی ZIP
        FloatingActionButton(
            onClick = { showInspectorSheet = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = if (showTapsellBanner) 54.dp else 16.dp, end = 16.dp)
                .navigationBarsPadding(),
            containerColor = Color(0xFF0284C7),
            contentColor = Color.White,
            shape = CircleShape
        ) {
            Icon(Icons.Default.Build, contentDescription = "تنظیمات قالب و خروجی")
        }

        // شیت تنظیمات و استخراج قالب مادر
        if (showInspectorSheet) {
            ModalBottomSheet(
                onDismissRequest = { showInspectorSheet = false },
                sheetState = sheetState,
                containerColor = Color(0xFF0F172A),
                contentColor = Color.White
            ) {
                TemplateInspectorSheet(
                    currentSourceType = currentSourceType,
                    currentUrl = currentUrl,
                    onSourceTypeChanged = { currentSourceType = it },
                    onUrlChanged = { currentUrl = it },
                    onReload = { webViewInstance?.reload() },
                    onTestInterstitial = {
                        TapsellAdManager.showInterstitial(
                            activity = activity,
                            zoneId = BuildConfig.TAPSELL_INTERSTITIAL_ZONE_ID.ifBlank { "test_interstitial" },
                            onSuccess = {
                                Toast.makeText(context, "تبلیغ بین‌برنامه‌ای تپسل با موفقیت اجرا شد", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    onTestRewarded = {
                        TapsellAdManager.showRewarded(
                            activity = activity,
                            zoneId = BuildConfig.TAPSELL_REWARDED_ZONE_ID.ifBlank { "test_rewarded" },
                            onRewarded = {
                                Toast.makeText(context, "جایزه تپسل با موفقیت دریافت گردید", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    onExportZip = {
                        exportTemplateZip(context)
                    }
                )
            }
        }
    }
}

@Composable
fun TemplateInspectorSheet(
    currentSourceType: String,
    currentUrl: String,
    onSourceTypeChanged: (String) -> Unit,
    onUrlChanged: (String) -> Unit,
    onReload: () -> Unit,
    onTestInterstitial: () -> Unit,
    onTestRewarded: () -> Unit,
    onExportZip: () -> Unit
) {
    var editUrlText by remember { mutableStateOf(currentUrl) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "🛠️ کنترل‌پنل قالب مادر Android Studio",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF38BDF8)
        )

        // مشخصات فنی جاری بیلد
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ConfigRow("نام برنامه (APP_NAME):", BuildConfig.APP_NAME)
                ConfigRow("شناسه پکیج (APP_ID):", BuildConfig.APP_ID)
                ConfigRow("نسخه (VERSION):", "${BuildConfig.VERSION_NAME} (کد: ${BuildConfig.VERSION_CODE})")
                ConfigRow("نوع منبع گرادل:", BuildConfig.SOURCE_TYPE)
                ConfigRow("وضعیت تپسل:", if (BuildConfig.TAPSELL_ENABLED) "فعال" else "غیرفعال")
            }
        }

        // انتخاب نوع منبع (URL vs HTML)
        Text("تغییر زنده منبع بارگذاری وب:", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onSourceTypeChanged("URL") },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (currentSourceType.equals("URL", true)) Color(0xFF0284C7) else Color(0xFF334155)
                )
            ) {
                Text("🌐 لینک اینترنتی (URL)")
            }

            Button(
                onClick = { onSourceTypeChanged("HTML") },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (currentSourceType.equals("HTML", true)) Color(0xFF0284C7) else Color(0xFF334155)
                )
            ) {
                Text("📄 فایل محلی HTML5")
            }
        }

        if (currentSourceType.equals("URL", true)) {
            OutlinedTextField(
                value = editUrlText,
                onValueChange = { editUrlText = it },
                label = { Text("آدرس URL دلخواه") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF0284C7),
                    unfocusedBorderColor = Color(0xFF475569),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true
            )
            Button(
                onClick = {
                    onUrlChanged(editUrlText)
                    onReload()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("بارگذاری این نشانی")
            }
        }

        // تست‌های تپسل
        Text("آزمایش تبلیغات تپسل:", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onTestInterstitial,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569))
            ) {
                Text("تبلیغ بین‌برنامه‌ای")
            }
            Button(
                onClick = onTestRewarded,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569))
            ) {
                Text("ویدیوی جایزه‌ای")
            }
        }

        // استخراج و اشتراک‌گذاری ZIP کامل پروژه
        Button(
            onClick = onExportZip,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.Share, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("استخراج و دانلود ZIP قالب مادر (android-webview-template.zip)")
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun ConfigRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = Color(0xFF94A3B8), fontSize = 12.sp)
        Text(text = value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

// استخراج و به اشتراک‌گذاری فایل ZIP قالب مادر رسمی
private fun exportTemplateZip(context: Context) {
    try {
        val assetName = "android-webview-template.zip"
        val outFile = File(context.cacheDir, assetName)

        context.assets.open(assetName).use { input ->
            FileOutputStream(outFile).use { output ->
                input.copyTo(output)
            }
        }

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile
        )

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "ارسال یا ذخیره سورس‌کد Android Studio"))
    } catch (e: Exception) {
        Toast.makeText(context, "خطا در استخراج ZIP: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    androidx.compose.material3.Text(text = "Hello $name!", modifier = modifier)
}
