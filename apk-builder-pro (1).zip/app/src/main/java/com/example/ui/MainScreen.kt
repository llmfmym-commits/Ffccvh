package com.example.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.generator.ApkBuilderEngine
import com.example.model.*
import com.example.ui.components.CodeViewerDialog
import com.example.ui.preview.WebVideoPreviewRunner

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: ApkBuilderViewModel) {
    val context = LocalContext.current
    val config by viewModel.config.collectAsState()
    val generatedItems by viewModel.generatedItems.collectAsState()
    val isBuilding by viewModel.isBuilding.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val isPreviewActive by viewModel.isPreviewActive.collectAsState()
    val isCodeViewerActive by viewModel.isCodeViewerActive.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }

    LaunchedEffect(statusMessage) {
        statusMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearStatusMessage()
        }
    }

    if (isPreviewActive) {
        WebVideoPreviewRunner(
            config = config,
            onClose = { viewModel.setPreviewActive(false) }
        )
        return
    }

    if (isCodeViewerActive) {
        CodeViewerDialog(
            config = config,
            onDismiss = { viewModel.setCodeViewerActive(false) }
        )
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF0B132B),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF10B981)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Android, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "APK Builder & Web Studio",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "مبدل وب، ویدیو و HTML به اپلیکیشن و APK",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.setPreviewActive(true) }) {
                        Icon(Icons.Default.PlayCircle, contentDescription = "اجرای زنده", tint = Color(0xFF10B981))
                    }
                    IconButton(onClick = { viewModel.setCodeViewerActive(true) }) {
                        Icon(Icons.Default.Code, contentDescription = "مشاهده کدها", tint = Color(0xFF38BDF8))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1C2541)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1C2541),
                contentColor = Color.White
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Build, contentDescription = "سازنده") },
                    label = { Text("سازنده و تنظیمات", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF38BDF8),
                        selectedTextColor = Color(0xFF38BDF8),
                        indicatorColor = Color(0xFF263252)
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { viewModel.setPreviewActive(true) },
                    icon = { Icon(Icons.Default.LiveTv, contentDescription = "پیش‌نمایش وب و ویدیو") },
                    label = { Text("پیش‌نمایش زنده", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF10B981),
                        selectedTextColor = Color(0xFF10B981),
                        indicatorColor = Color(0xFF263252)
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = {
                        BadgedBox(badge = {
                            if (generatedItems.isNotEmpty()) {
                                Badge(containerColor = Color(0xFF0284C7)) {
                                    Text("${generatedItems.size}", color = Color.White)
                                }
                            }
                        }) {
                            Icon(Icons.Default.FolderZip, contentDescription = "خروجی‌ها")
                        }
                    },
                    label = { Text("فایل‌های APK", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFF59E0B),
                        selectedTextColor = Color(0xFFF59E0B),
                        indicatorColor = Color(0xFF263252)
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> BuilderStudioContent(
                    config = config,
                    viewModel = viewModel,
                    isBuilding = isBuilding
                )
                2 -> OutputsListContent(
                    items = generatedItems,
                    onInstall = { item -> ApkBuilderEngine.installApk(context, item.filePath) },
                    onShare = { item -> ApkBuilderEngine.shareApkFile(context, item.filePath, item.appName) },
                    onDelete = { item -> viewModel.deleteItem(item) }
                )
                else -> BuilderStudioContent(
                    config = config,
                    viewModel = viewModel,
                    isBuilding = isBuilding
                )
            }

            if (isBuilding) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.75f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = Color(0xFF0284C7))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "در حال تولید خروجی...",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "کامپایل منابع، استخراج فایل‌ها و بسته‌بندی پکیج",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BuilderStudioContent(
    config: ApkProjectConfig,
    viewModel: ApkBuilderViewModel,
    isBuilding: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Action Bar
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2541)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "🚀 ساخت و خروجی پروژه",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.buildApk() },
                        enabled = !isBuilding,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("build_apk_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تولید APK واقعی", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.setPreviewActive(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("preview_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تست زنده وب/ویدیو", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.exportProjectZip() },
                        enabled = !isBuilding,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("export_zip_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF38BDF8)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("دانلود سورس ZIP", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.setCodeViewerActive(true) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("view_code_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF59E0B)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("کدهای کاتلین/جاوا", fontSize = 11.sp)
                    }
                }
            }
        }

        // Section 1: Source Type
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2541)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "۱. نوع منبع اپلیکیشن (Source)",
                    color = Color(0xFF38BDF8),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppSourceType.values().forEach { type ->
                        val isSelected = config.sourceType == type
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.updateSourceType(type) },
                            label = { Text(type.titleFa, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0284C7),
                                selectedLabelColor = Color.White,
                                containerColor = Color(0xFF263252),
                                labelColor = Color(0xFFCBD5E1)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                when (config.sourceType) {
                    AppSourceType.PUBLIC_URL -> {
                        OutlinedTextField(
                            value = config.sourceUrl,
                            onValueChange = { viewModel.updateSourceUrl(it) },
                            label = { Text("آدرس اینترنتی یا لینک ویدیو (URL)") },
                            leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, tint = Color(0xFF38BDF8)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("source_url_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF0284C7),
                                unfocusedBorderColor = Color(0xFF334155),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("پیش‌فرض‌های سریع:", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SuggestionChip(
                                onClick = { viewModel.updateSourceUrl("https://www.aparat.com") },
                                label = { Text("آپارات ویدیو", fontSize = 10.sp) }
                            )
                            SuggestionChip(
                                onClick = { viewModel.updateSourceUrl("https://fa.wikipedia.org") },
                                label = { Text("ویکی‌پدیا", fontSize = 10.sp) }
                            )
                            SuggestionChip(
                                onClick = { viewModel.updateSourceUrl("https://archive.org") },
                                label = { Text("آرشیو ویدیو و مدیا", fontSize = 10.sp) }
                            )
                            SuggestionChip(
                                onClick = { viewModel.updateSourceUrl("https://html5demos.com") },
                                label = { Text("تست HTML5", fontSize = 10.sp) }
                            )
                        }
                    }

                    AppSourceType.HTML_CODE, AppSourceType.HTML_FILE -> {
                        Text(
                            text = "کد HTML5 محلی (شامل پخش‌کننده ویدیویی و تست میکروفون)",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = config.htmlContent,
                            onValueChange = { viewModel.updateHtmlContent(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .testTag("html_code_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF0284C7),
                                unfocusedBorderColor = Color(0xFF334155),
                                focusedTextColor = Color(0xFFE2E8F0),
                                unfocusedTextColor = Color(0xFFCBD5E1)
                            ),
                            textStyle = androidx.compose.ui.text.TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    AppSourceType.PROJECT_ZIP -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF263252), RoundedCornerShape(10.dp))
                                .padding(14.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Archive, contentDescription = null, tint = Color(0xFFF59E0B))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("پشتیبانی از فایل ZIP پروژه‌های کاتلین و جاوا", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "این استودیو سورس خام پروژه اندروید را دریافت و قالب استاندارد وب‌ویو، ویدیوی تمام صفحه و SDK تپسل را روی آن بسته‌بندی می‌کند.",
                                    color = Color(0xFFCBD5E1),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 2: App Identity & Logo
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2541)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "۲. مشخصات و لوگوی اپلیکیشن",
                    color = Color(0xFF38BDF8),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Logo Preview & Selector
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        when (config.customLogoName) {
                                            "purple" -> Color(0xFF7C3AED)
                                            "emerald" -> Color(0xFF059669)
                                            "amber" -> Color(0xFFD97706)
                                            else -> Color(0xFF0284C7)
                                        },
                                        Color(0xFF0B132B)
                                    )
                                )
                            )
                            .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = config.appName.firstOrNull()?.toString() ?: "A",
                            color = Color.White,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text("انتخاب رنگ و سبک لوگوی برنامه:", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("blue" to Color(0xFF0284C7), "emerald" to Color(0xFF10B981), "purple" to Color(0xFF8B5CF6), "amber" to Color(0xFFF59E0B)).forEach { (key, color) ->
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .clickable { viewModel.updateCustomLogoName(key) }
                                        .border(
                                            width = if (config.customLogoName == key) 2.dp else 0.dp,
                                            color = Color.White,
                                            shape = CircleShape
                                        )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = config.appName,
                    onValueChange = { viewModel.updateAppName(it) },
                    label = { Text("نام برنامه (App Name)") },
                    leadingIcon = { Icon(Icons.Default.Title, contentDescription = null, tint = Color(0xFF38BDF8)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF0284C7),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = config.packageName,
                    onValueChange = { viewModel.updatePackageName(it) },
                    label = { Text("شناسه پکیج (Package ID)") },
                    leadingIcon = { Icon(Icons.Default.Fingerprint, contentDescription = null, tint = Color(0xFF10B981)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("package_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF0284C7),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = config.versionName,
                        onValueChange = { viewModel.updateVersionName(it) },
                        label = { Text("نسخه برنامه") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF0284C7),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Language Selector
                    Column(modifier = Modifier.weight(1f)) {
                        Text("زبان سورس پروژه:", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            LanguageType.values().forEach { lang ->
                                FilterChip(
                                    selected = config.language == lang,
                                    onClick = { viewModel.updateLanguage(lang) },
                                    label = { Text(lang.displayName, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFF0284C7),
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 3: Android Permissions Selector
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2541)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "۳. تنظیم مجوزهای اندروید (Permissions)",
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "${config.permissions.size} مجوز فعال",
                        color = Color(0xFF10B981),
                        fontSize = 11.sp
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))

                AppPermission.values().forEach { perm ->
                    val isChecked = config.permissions.contains(perm)
                    Surface(
                        color = if (isChecked) Color(0xFF263252) else Color.Transparent,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clickable { viewModel.togglePermission(perm) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { viewModel.togglePermission(perm) },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = Color(0xFF0284C7),
                                    uncheckedColor = Color(0xFF64748B)
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = perm.titleFa,
                                    color = if (isChecked) Color.White else Color(0xFFCBD5E1),
                                    fontSize = 12.sp,
                                    fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(
                                    text = perm.descFa,
                                    color = Color(0xFF94A3B8),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 4: Web & Video View Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2541)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "۴. تنظیمات وب و پخش ویدیو",
                    color = Color(0xFF38BDF8),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                SettingSwitchRow(
                    title = "شتاب سخت‌افزاری (Hardware Acceleration)",
                    desc = "افزایش روانی پخش ویدیوهای با کیفیت بالا و رندرهای CSS",
                    checked = config.enableHardwareAcceleration,
                    onCheckedChange = { viewModel.updateHardwareAcceleration(it) }
                )

                SettingSwitchRow(
                    title = "اجرای کدهای جاوا اسکریپت (JavaScript)",
                    desc = "برای عملکرد کامل وب‌سایت‌ها، ویدیوپلیرها و تعاملات",
                    checked = config.enableJavaScript,
                    onCheckedChange = { viewModel.updateJavaScript(it) }
                )

                SettingSwitchRow(
                    title = "پشتیبانی از فایلهای محلی (Allow File Access)",
                    desc = "امکان لود محتوای آفلاین و منابع از حافظه داخلی",
                    checked = config.allowFileAccess,
                    onCheckedChange = { viewModel.updateAllowFileAccess(it) }
                )
            }
        }

        // Section 5: Tapsell Ad SDK Integration
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2541)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "۵. ادغام تبلیغات تپسل (Tapsell SDK)",
                            color = Color(0xFFF59E0B),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "جایگزینی و پیاده‌سازی کامل SDK تبلیغاتی تپسل پلاس",
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = config.tapsellConfig.enabled,
                        onCheckedChange = { viewModel.updateTapsellEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFFF59E0B)
                        )
                    )
                }

                if (config.tapsellConfig.enabled) {
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = config.tapsellConfig.appKey,
                        onValueChange = { viewModel.updateTapsellAppKey(it) },
                        label = { Text("کلید اپلیکیشن تپسل (App Key)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFF59E0B),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = config.tapsellConfig.bannerZoneId,
                        onValueChange = { viewModel.updateTapsellBannerZone(it) },
                        label = { Text("شناسه زون بنر استاندارد (Banner Zone ID)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFF59E0B),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = config.tapsellConfig.interstitialZoneId,
                        onValueChange = { viewModel.updateTapsellInterstitialZone(it) },
                        label = { Text("شناسه زون بین‌برنامه‌ای (Interstitial Zone ID)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFF59E0B),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun SettingSwitchRow(
    title: String,
    desc: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(desc, color = Color(0xFF94A3B8), fontSize = 10.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF0284C7)
            )
        )
    }
}

@Composable
fun OutputsListContent(
    items: List<GeneratedApkItem>,
    onInstall: (GeneratedApkItem) -> Unit,
    onShare: (GeneratedApkItem) -> Unit,
    onDelete: (GeneratedApkItem) -> Unit
) {
    if (items.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.CloudDownload,
                    contentDescription = null,
                    tint = Color(0xFF64748B),
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "هنوز فایلی تولید نشده است",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "برای دریافت فایل خروجی، به تب «سازنده و تنظیمات» رفته و دکمه «تولید APK واقعی» یا «دانلود سورس ZIP» را بزنید.",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items, key = { it.id }) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C2541)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (item.isApk) Color(0xFF0284C7) else Color(0xFFF59E0B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    if (item.isApk) Icons.Default.Android else Icons.Default.FolderZip,
                                    contentDescription = null,
                                    tint = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.fileName,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "حجم: ${item.fileSizeFormatted}",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }
                            IconButton(onClick = { onDelete(item) }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFEF4444))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (item.isApk) {
                                Button(
                                    onClick = { onInstall(item) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.InstallMobile, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("نصب APK", fontSize = 11.sp)
                                }
                            }

                            Button(
                                onClick = { onShare(item) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("اشتراک‌گذاری", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
